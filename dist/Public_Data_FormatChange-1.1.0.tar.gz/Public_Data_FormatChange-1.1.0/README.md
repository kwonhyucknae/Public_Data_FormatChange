# Public_Data_FormatChange

Welcome!

Public_Data_FormatChange is Korea's publicdata format change programm
ex) Latitude: 35도 13분 57.5초  -> 35.232640 


